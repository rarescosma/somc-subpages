http_path = "/"

sass_dir = "."
css_dir = "."

output_style = :expanded

relative_assets = true

line_comments = false

sass_options = {
  :sourcemap => true
}