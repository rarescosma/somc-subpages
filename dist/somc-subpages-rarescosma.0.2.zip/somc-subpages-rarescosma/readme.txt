This plugin can be used as a Wordpress Widget and as a Wordpress Shortcode. It displays
all subpages of the page it is placed on. 
